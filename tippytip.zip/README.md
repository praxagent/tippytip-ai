# TippyTip Landing Page

This is a modern, responsive landing page for TippyTip, an iOS application for saving, organizing, and consuming web content with advanced features like AI-powered summaries, audio playback, and iCloud synchronization.

## Features

- Modern, clean design with a focus on user experience
- Fully responsive layout that works on all devices
- Optimized for fast loading
- Semantic HTML5 structure
- CSS3 with flexbox and grid layouts
- Smooth scrolling and animations
- Privacy policy page that complies with App Store requirements
- Terms of service page
- Cookie policy page with detailed information about cookie usage
- Cookie consent banner with customization options
- Contact form for user inquiries
- SEO optimized with meta tags and structured data
- Social media sharing support with Open Graph and Twitter Card meta tags

## File Structure

```
landing_page/
├── index.html                  # Main landing page
├── app_store_privacy_policy.html  # Privacy policy for App Store
├── terms_of_service.html       # Terms of service page
├── cookie_policy.html          # Cookie policy page
├── contact.html                # Contact form page
├── 404.html                    # Custom 404 error page
├── 500.html                    # Custom 500 error page
├── styles.css                  # Main stylesheet
├── script.js                   # JavaScript functionality
├── robots.txt                  # Instructions for search engine crawlers
├── sitemap.xml                 # XML sitemap for search engines
├── .htaccess                   # Server configuration for performance and security
├── images/                     # Directory for images (placeholders currently)
│   ├── favicon.ico             # Favicon placeholder
│   ├── apple-touch-icon.png    # Apple touch icon placeholder
│   ├── og-image.png            # Open Graph image placeholder
│   └── twitter-card-image.png  # Twitter card image placeholder
└── README.md                   # This file
```

## Setup Instructions

1. Clone or download this repository
2. Replace placeholder elements with your actual images:
   - Logo placeholder in the header and footer
   - App Store badge
   - Hero image
   - Step images in the "How It Works" section
   - Favicon and Apple touch icon
   - Open Graph and Twitter card images

## Image Placeholders

The landing page currently uses CSS-based placeholders instead of actual images. To replace them with real images:

### Logo
Replace the `.logo-placeholder` div with an actual image:
```html
<img src="images/your-logo.png" alt="TippyTip Logo" width="40" height="40">
```

### App Store Badges
Replace the placeholder divs with actual App Store badges:
```html
<img src="images/app-store-badge.svg" alt="Download on the App Store">
```

### Hero Image
Replace the `.hero-image-placeholder` div with your actual app screenshot:
```html
<img src="images/hero-device.png" alt="TippyTip App on iPhone and Mac">
```

### Step Images
Replace each `.step-image-placeholder` div with actual screenshots:
```html
<img src="images/step1.png" alt="Save Content Screenshot">
```

### SEO and Social Media Images
Replace the placeholder files with actual images:
- `favicon.ico` - 16x16, 32x32, and 48x48 pixel versions
- `apple-touch-icon.png` - 180x180 pixels
- `og-image.png` - 1200x630 pixels (for Facebook, LinkedIn)
- `twitter-card-image.png` - 1200x600 pixels (for Twitter)

## Customization

### Colors
The main colors are defined as CSS variables in the `:root` selector in `styles.css`. You can easily change the color scheme by modifying these variables:

```css
:root {
    --primary-color: #4a6cf7;
    --primary-dark: #3a56d4;
    /* other color variables */
}
```

### Fonts
The landing page uses the Inter font from Google Fonts. To change the font:

1. Update the Google Fonts link in the `<head>` section of both HTML files
2. Update the `--font-family` variable in the CSS

### Content
You can easily update the content by editing the text in the HTML files. The structure is organized into clear sections:

- Hero section
- Features
- How It Works
- Testimonials
- FAQ
- Download section
- Footer

### SEO and Social Media
The landing page includes meta tags for SEO and social media sharing. Update these in the `<head>` section of each HTML file:

```html
<!-- SEO Meta Tags -->
<meta name="description" content="Your description here">
<meta name="keywords" content="your, keywords, here">

<!-- Open Graph Meta Tags -->
<meta property="og:title" content="Your title here">
<meta property="og:description" content="Your description here">
<meta property="og:image" content="https://yourdomain.com/images/og-image.png">

<!-- Twitter Card Meta Tags -->
<meta name="twitter:card" content="summary_large_image">
<meta name="twitter:title" content="Your title here">
<meta name="twitter:description" content="Your description here">
<meta name="twitter:image" content="https://yourdomain.com/images/twitter-card-image.png">
```

### Cookie Consent Banner
The landing page includes a cookie consent banner that appears at the bottom of the page for first-time visitors. The banner is implemented in JavaScript and can be customized in the `script.js` file.

The banner offers three options:
- Accept All Cookies
- Accept Only Necessary Cookies
- Customize (redirects to the Cookie Policy page)

User preferences are stored in localStorage to prevent the banner from appearing on subsequent visits.

## Browser Compatibility

The landing page is compatible with:
- Chrome (latest)
- Firefox (latest)
- Safari (latest)
- Edge (latest)
- Mobile browsers (iOS Safari, Android Chrome)

## Performance Optimization

- Minimal JavaScript for essential functionality
- CSS optimized for performance
- Responsive images (when you add them)
- Efficient animations that don't impact performance

## License

This landing page template is available for use with the TippyTip application.

## Contact

For any questions or support, please contact:
- Email: support@tippytip.app
- Website: https://tippytip.app

## Recent Improvements

The following improvements have been made to the landing page:

1. **Mobile Navigation**: Implemented a responsive mobile navigation menu with a hamburger toggle button for all pages.

2. **Lazy Loading**: Added lazy loading functionality for images to improve page load performance.

3. **Social Media Sharing**: Implemented social media sharing buttons for Twitter, Facebook, LinkedIn, and email.

4. **SEO Enhancements**:
   - Added schema.org structured data for both the software application and organization
   - Created a sitemap.xml file for better search engine indexing
   - Added Open Graph and Twitter Card meta tags for improved social sharing
   - Created a robots.txt file with proper directives

5. **Performance Optimizations**:
   - Added an .htaccess file with GZIP compression, browser caching, and security headers
   - Implemented lazy loading for images
   - Optimized CSS for better rendering performance

6. **Security Enhancements**:
   - Added security headers in .htaccess (X-XSS-Protection, X-Content-Type-Options, X-Frame-Options, CSP)
   - Implemented HTTPS redirection
   - Added proper input validation on the contact form

7. **User Experience Improvements**:
   - Added custom error pages (404, 500)
   - Implemented a cookie consent banner with customization options
   - Added smooth scrolling for anchor links
   - Created animations for page elements on scroll

8. **Compliance**:
   - Added a comprehensive privacy policy page
   - Created a detailed cookie policy page
   - Added terms of service page
   - Implemented a GDPR-compliant cookie consent banner

9. **Additional Pages**:
   - Contact form page with validation
   - Custom 404 and 500 error pages
   - Privacy policy, terms of service, and cookie policy pages

10. **Platform Focus**:
    - Updated content to focus exclusively on iOS (iPhone and iPad)
    - Removed macOS download options
    - Adjusted messaging to highlight mobile experience

## Upcoming Improvements

The following improvements are planned for future updates:

1. Replace placeholder images with actual app screenshots and logos
2. Add actual App Store links when available
3. Add analytics tracking
4. Implement A/B testing for key conversion elements
5. Create a blog section for content marketing
6. Add real customer testimonials with feedback
7. Further optimize images for faster loading 